function loadLog(){		

		$.ajax({
			url: "log.txt",
			cache: false,
			success: function(html){		
				$("#chatbox").html(html); //Insert chat log into the #chatbox div				
		  	},
		});
	}

// jQuery Document
$(document).ready(function(){
	//If user wants to end session
	$("#exit").click(function(){
		var exit = confirm("Are you sure you want to end the session?");
		if(exit==true){window.location = 'Chat.php?logout=true';}		
	});
});

//If user submits the form
$("#submitmsg").click(function () {
        window.alert("Something happened");
        var clientmsg = $.trim($("#usermsg").val());
        if (clientmsg.length >= 3) {

        } else {
        $.post("post.php", { text: clientmsg });
        $("#usermsg").attr("value", "");
        return false;
        }
    });

/*****
<script>
    //Load the file containing the chat log
	function loadLog(){		

		$.ajax({
			url: "log.txt",
			cache: false,
			success: function(html){		
				$("#chatbox").html(html); //Insert chat log into the #chatbox div				
		  	},
		});
	}
</script>
<script type="text/javascript">
// jQuery Document
$(document).ready(function(){
	//If user wants to end session
	$("#exit").click(function(){
		var exit = confirm("Are you sure you want to end the session?");
		if(exit==true){window.location = 'Chat.php?logout=true';}		
	});
});
    
</script>
<script type="text/javascript">
    //If user submits the form
    $("#submitmsg").click(function () {
        window.alert("Something happened");
        var clientmsg = $.trim($("#usermsg").val());
        if (clientmsg.length >= 3) {

        } eth
        $.post("post.php", { text: clientmsg });
        $("#usermsg").attr("value", "");
        return false;
    });
</script>
***/