
 <table class="backcolor" cellspacing="0">
        <tr class="bannerback">
			<td width ="50px"> </td>
	    
            <td>
                <img src="bannerlogo.png" class="bannerimage" alt="Lingle logo">
            </td>
            <td width ="60%"> </td>
	    
            
            <td >
                <img src="bannercorner.png" class="bannerimage" alt="Lingle banner">
            </td>
        </tr>

        <tr class="menuback">
            <td colspan="4"><table class="backcolor">
		    <ul>
                <li <?php echo ($page == "index") ? 'class="active"' : ''; ?>><a href="index.php"><b>Home</b></a></li>
                <li <?php echo ($page == "chat") ? 'class="active"' : ''; ?>><a href="chat.php"><b>Chat</b></a></li>
                <li <?php echo ($page == "contact") ? 'class="active"' : ''; ?>><a href="contact.php"><b>Contact Us</b></a></li>
                <li <?php echo ($page == "how") ? 'class="active"' : ''; ?>><a href="how.php" ><b>How it Works</b></a></li>
            </ul>
        </td>
    </tr>
</table>