<!DOCTYPE html>

<html lang="en">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <meta charset="utf-8" />
        <title>Lingle - Home</title>
    </head>
<body>
    <?php
        $page = "index";
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php');
    ?>
    <table> 
        <tr>
            <!--Description of website box-->
            <td class="intro">
                <p>Lingle is a social drop-in messaging site. Just hit the chat button to contact a random person from across the world!</p>
            </td>
            <td rowspan="3" class="twitter" >
                <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/LingleChat" data-widget-id="707761782522322944">Tweets by @LingleChat</a>
                <script>
                    ! function(d, s, id) {
                        var js, fjs = d.getElementsByTagName(s)[0],
                            p = /^http:/.test(d.location) ? 'http' : 'https';
                        if (!d.getElementById(id)) {
                            js = d.createElement(s);
                            js.id = id;
                            js.src = p + "://platform.twitter.com/widgets.js";
                            fjs.parentNode.insertBefore(js, fjs);
                        }
                    }(document, "script", "twitter-wjs");
                </script>
            </td>
        </tr>
	    <tr>
			<td style="text-align: center"> <hr style="color: #EAEDED">
                <p class="chat">
                    <a href="chat.php" class="chats">
                        <img src="images/chat.png" alt="Chat" height="100px" width="110px"><br>Join Chat Room Here!
                    </a>
                </p>
            </td>
		</tr>	
    </table>
    <?php
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php');
    ?>
</body>
	
</html>