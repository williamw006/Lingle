<?php
//Login
session_start();
 
/*function loginform(){
    echo'
    <div id="loginform">
    <form action="chat.php" method="post">
        <p>Please enter your name to continue:</p>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" />
        <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
    </div>
    ';
}
 
if(isset($_POST['enter'])){
    if($_POST['name'] != ""){
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    }
    else{
        echo '<span class="error">Please type in a name</span>';
    }
}*/
?>

<!--Start-->
<!DOCTYPE html>

<html lang="en">

<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Lingle - Home</title>
    
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>
    <script type="text/javascript" src="js/chat-send.js"></script>
</head>
<body onload="setInterval('chat.update()', 1000)">

<?php
/*if(!isset($_SESSION['name'])){
        loginForm();
    }
    else{
        if(isset($_GET['logout'])){ 
            //Simple exit message
            $fp = fopen("log.txt", 'a');
            fwrite($fp, "<div class='msgln'><i>User ". $_SESSION['name'] ." has left the chat session.</i><br></div>");
            fclose($fp);
     
            session_destroy();
            header("Location: chat.php"); //Redirect the user
        }*/
?>
    <?php
        $page = "chat";
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php');
    ?>
	<table class="details">
        <!--Announcements-->
		<tr class="detail">
			<td style="width: 25%"><b>Announcement:</b> </td><td style="width: 25%" colspan="2" ><marquee> Cat loves Dogs!</marquee></td>
		</tr>
        <!--BBC news-->
		<tr>
		    <td style="width: 25%" rowspan="3" class="detail2">
                <!--Feedwind code -->
                <script type="text/javascript">
                    document.write('\x3Cscript type="text/javascript" src="' + ('https:' == document.location.protocol ? 'https://' : 'http://') + 'feed.mikle.com/js/rssmikle.js">\x3C/script>');
                </script>
                <script type="text/javascript">
                    (function() {
                        var params = {
                            rssmikle_url: "http://feeds.bbci.co.uk/news/world/rss.xml|http://www.cbn.com/cbnnews/world/feed/|http://feeds.reuters.com/Reuters/worldNews",
                            rssmikle_frame_width: "300",
                            rssmikle_frame_height: "400",
                            frame_height_by_article: "0",
                            rssmikle_target: "_blank",
                            rssmikle_font: "Arial, Helvetica, sans-serif",
                            rssmikle_font_size: "12",
                            rssmikle_border: "off",
                            responsive: "off",
                            rssmikle_css_url: "",
                            text_align: "left",
                            text_align2: "left",
                            corner: "off",
                            scrollbar: "on",
                            autoscroll: "on",
                            scrolldirection: "up",
                            scrollstep: "3",
                            mcspeed: "20",
                            sort: "Off",
                            rssmikle_title: "on",
                            rssmikle_title_sentence: "RSS Feed",
                            rssmikle_title_link: "http://none",
                            rssmikle_title_bgcolor: "#0430de",
                            rssmikle_title_color: "#FFFFFF",
                            rssmikle_title_bgimage: "",
                            rssmikle_item_bgcolor: "#FFFFFF",
                            rssmikle_item_bgimage: "",
                            rssmikle_item_title_length: "55",
                            rssmikle_item_title_color: "#0430de",
                            rssmikle_item_border_bottom: "on",
                            rssmikle_item_description: "on",
                            item_link: "off",
                            rssmikle_item_description_length: "100",
                            rssmikle_item_description_color: "#666666",
                            rssmikle_item_date: "gl1",
                            rssmikle_timezone: "Etc/GMT",
                            datetime_format: "%b %e, %Y %l:%M %p",
                            item_description_style: "text+tn",
                            item_thumbnail: "full",
                            item_thumbnail_selection: "auto",
                            article_num: "15",
                            rssmikle_item_podcast: "off",
                            keyword_inc: "",
                            keyword_exc: ""
                        };
                        feedwind_show_widget_iframe(params);
                    })();
                </script>
                <!--End feedwind code-->
            </td>
            <!--Outputbox-->
            <td>
                <p class="welcome">Welcome, <b><?php //echo $_SESSION['name']; ?></b></p>
                

    <div id="page-wrap">
    

        
        <p id="name-area"></p>
        
        <div id="chat-wrap"><div id="chat-area"></div></div>
        
        <form id="send-message-area">
            <p>Your message: </p>
            <textarea id="sendie" maxlength = '100' ></textarea>
        </form>
    
    </div>

			    
            </td>
			<td style="width: 25%" class="detail3">
                <button type="submit" value="Send" class="button">Leave Chat</button><br>
                <button type="submit" value="Send" class="button">Report</button></td>
		</tr>
		<tr>
		    <td style="width: 25%" rowspan="2"  class="detail2">Advertisement</td>
		</tr>
    </table>
    <?php
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php');
    ?>
</body>
</html>