<!DOCTYPE html>

<html lang="en">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <meta charset="utf-8" />
        <title>Lingle - Home</title>
    </head>
<body>
    <?php
        $page = "help";
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/header.php');
    ?>
    <table class="details" style="text-align: center; height: 50%"> 
        <tr>
            <td>
		        <p class="text">FAQ</p>
		    </td>
        </tr>
    </table>
    <?php
        include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php');
    ?>
</body>
	
</html>