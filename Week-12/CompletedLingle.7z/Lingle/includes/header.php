<table class="backcolor" cellspacing="0">
    <tr class="bannerback">
		<td>
            <img src="images/banner.png" height="150px" width="100%" alt="Lingle banner">
            <img src="images/badge.png" height="152em" width="10%" alt="Lingle logo" style="position: absolute; left: 8%; top: 0">
            <img src="images/design.png" height="150em" width="150px" alt="Lingle design" style="position: absolute; right: 0%; top: 2px">
            
        </td>
    </tr>
    <tr class="menuback">
        <td>
		    <ul>
                <li <?php echo ($page == "index") ? 'class="active"' : ''; ?>><a href="index.php"><b>Home</b></a></li>
                <li <?php echo ($page == "chat") ? 'class="active"' : ''; ?>><a href="chat.php"><b>Chat</b></a></li>
                <li <?php echo ($page == "help") ? 'class="active"' : ''; ?>><a href="help.php" ><b>Help</b></a></li>
            </ul>
        </td>
    </tr>
</table>