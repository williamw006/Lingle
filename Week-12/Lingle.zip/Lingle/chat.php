<?php
//Login
session_start();
 
function loginform(){
    echo'
    <div id="loginform">
    <form action="chat.php" method="post">
        <p>Please enter your name to continue:</p>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" />
        <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
    </div>
    ';
}
 
if(isset($_POST['enter'])){
    if($_POST['name'] != ""){
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    }
    else{
        echo '<span class="error">Please type in a name</span>';
    }
}
?>

<!--Start-->
<!DOCTYPE html>

<html lang="en">
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8" />
        <title>Lingle - Home</title>
    </head>
<body>

<?php
if(!isset($_SESSION['name'])){
        loginForm();
    }
    else{
        if(isset($_GET['logout'])){ 
            //Simple exit message
            $fp = fopen("log.txt", 'a');
            fwrite($fp, "<div class='msgln'><i>User ". $_SESSION['name'] ." has left the chat session.</i><br></div>");
            fclose($fp);
     
            session_destroy();
            header("Location: chat.php"); //Redirect the user
        }
?>

    <table class="backcolor">
        <tr class="menuback">
		    <td>
                <img src="Banner.png" height="150em" width="100%">
            </td>
        </tr>
        <tr class="menuback">
            <td>
	            <ul>
                    <li><a href="index.html" ><b >Home</b></a></li>
                    <li><a href="chat.php" ><b>Chat</b></a></li>
                    <li><a href="contact.html" ><b>Contact Us</b></a></li>
                    <li><a href="how.html" ><b>How It Works</b></a></li>
                </ul>
            </td>
        </tr>
    </table>
	<table class="details" align="center">
        <!--Announcements-->
		<tr class="detail">
			<td width="25%"  ><b>Announcement:</b> </td><td width="25%" colspan="2" ><marquee> Cat loves Dogs!</marquee></td>
		</tr>
        <!--BBC news-->
		<tr>
		    <td width="25%" rowspan="3" class="detail2">
                <!--Feedwind code -->
                <script type="text/javascript">
                    document.write('\x3Cscript type="text/javascript" src="' + ('https:' == document.location.protocol ? 'https://' : 'http://') + 'feed.mikle.com/js/rssmikle.js">\x3C/script>');
                </script>
                <script type="text/javascript">
                    (function() {
                        var params = {
                            rssmikle_url: "http://feeds.bbci.co.uk/news/world/rss.xml|http://www.cbn.com/cbnnews/world/feed/|http://feeds.reuters.com/Reuters/worldNews",
                            rssmikle_frame_width: "300",
                            rssmikle_frame_height: "400",
                            frame_height_by_article: "0",
                            rssmikle_target: "_blank",
                            rssmikle_font: "Arial, Helvetica, sans-serif",
                            rssmikle_font_size: "12",
                            rssmikle_border: "off",
                            responsive: "off",
                            rssmikle_css_url: "",
                            text_align: "left",
                            text_align2: "left",
                            corner: "off",
                            scrollbar: "on",
                            autoscroll: "on",
                            scrolldirection: "up",
                            scrollstep: "3",
                            mcspeed: "20",
                            sort: "Off",
                            rssmikle_title: "on",
                            rssmikle_title_sentence: "RSS Feed",
                            rssmikle_title_link: "http://none",
                            rssmikle_title_bgcolor: "#0430de",
                            rssmikle_title_color: "#FFFFFF",
                            rssmikle_title_bgimage: "",
                            rssmikle_item_bgcolor: "#FFFFFF",
                            rssmikle_item_bgimage: "",
                            rssmikle_item_title_length: "55",
                            rssmikle_item_title_color: "#0430de",
                            rssmikle_item_border_bottom: "on",
                            rssmikle_item_description: "on",
                            item_link: "off",
                            rssmikle_item_description_length: "100",
                            rssmikle_item_description_color: "#666666",
                            rssmikle_item_date: "gl1",
                            rssmikle_timezone: "Etc/GMT",
                            datetime_format: "%b %e, %Y %l:%M %p",
                            item_description_style: "text+tn",
                            item_thumbnail: "full",
                            item_thumbnail_selection: "auto",
                            article_num: "15",
                            rssmikle_item_podcast: "off",
                            keyword_inc: "",
                            keyword_exc: ""
                        };
                        feedwind_show_widget_iframe(params);
                    })();
                </script>
                <!--End feedwind code-->
            </td>
            <!--Outputbox-->
            <td>
                <p class="welcome">Welcome, <b><?php echo $_SESSION['name']; ?></b></p>
			    <form>
                    <input type="text"id="message" autofocus="true"></input>
                    <input type="button" value="Send" onclick="sendMessage();"></input>
                </form>
                <div id="messages"></div>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
                <script>
                $(document).ready(function () {
                    $("#messages").keypress(function (e) {
                        e.preventDefault();
                        var key = e.which;
                        if (key == 13)  // the enter key code
                        {
                            sendMessage();
                        }
                    });
                })
                function sendMessage() {
                    var $entered_text = $("#message").val()
                    $("#messages").append($entered_text + "<br>");
                    $("#message").val("");
                }
                </script>
            </td>
            <!--Side options-->
			<td width="25%" class="detail3">
                <button type="submit" value="Send" class="button">Leave Chat</button><br>
                <button type="submit" value="Send" class="button">Report</button></td>
		</tr>
		<tr>
		    <td width="25%" rowspan="2"  class="detail2">advertisement</td>
		</tr>
    </table><hr class="attributes">
    <!--Bottom of page-->
    <table class="backpara">
        <tr>
            <td class="para1"><h2>ONLINE CHATTERS</h2> </td>
            <td class="para1"><h2> WEBSITE NEWS</h2></td>
            <td class="para2"><h2>POPULAR CHAT TOPICS</h2></td>
        </tr>
        <tr>
			<td class="para1"> <h1>53</h1></td>
            <td class="para1"><h3></h3></td>
			<td>
                <h3>
                    <a href="index.html" class="linkh3">Entertainment</a><br>
                    <a href="index.html" class="linkh3">Cats vs Dogs</a><br>
                    <a href="index.html" class="linkh3">How great is Lingle? ;)</a>
                </h3>
            </td>
	    </tr>
    </table>
    <table class="width">
	    <tr>
            <td class="footer"><p class="textdisp">Copyright@Lingle.inc. 2016</p></td>
        </tr>
    </table>
</body>
<?php
}
?>
</html>