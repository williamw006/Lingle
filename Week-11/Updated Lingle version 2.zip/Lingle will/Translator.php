<?php

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Lingle Translator</title>
    </head>
    <body>
        <td width="25%" class="detail3">
                <h1>Translator</h1>
      <form action="" method="POST">
      <input type="text" name="message">
        <input type="submit">
      </form>
    <div id="sourceText">
    <?php echo $_POST['message']; ?>
    </div>
    <div id="translation"></div>
    <div id="messages"></div>
    <script>
      function translateText(response) {
        document.getElementById("translation").innerHTML += "<br>" + response.data.translations[0].translatedText;
      }
    </script>
    <script>
        var newScript = document.createElement('script');
        newScript.type = 'text/javascript';
        var sourceText = escape(document.getElementById("sourceText").innerHTML);
        // WARNING: be aware that YOUR-API-KEY inside html is viewable by all your users.
        // Restrict your key to designated domains or use a proxy to hide your key
        // to avoid misusage by other party.
        var source = 'https://www.googleapis.com/language/translate/v2?key=AIzaSyC59610ZIcjelmT6lu6tlkfMGfVree0iJw&source=en&target=de&callback=translateText&q=' + sourceText;
        newScript.src = source;

        // When we add this script to the head, the request is sent off.
        document.getElementsByTagName('head')[0].appendChild(newScript);
        sendMessage();

        function sendMessage() {
            var $entered_text = $("#message").val()
            $("#messages").append($entered_text + "<br>");
            $("#message").val("");
        }
    </script>
        
    </body>
</html>
