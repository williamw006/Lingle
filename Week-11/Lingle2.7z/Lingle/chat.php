<?php
//Login
session_start();
 
/*function loginform(){
    echo'
    <div id="loginform">
    <form action="chat.php" method="post">
        <p>Please enter your name to continue:</p>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" />
        <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
    </div>
    ';
}
 
if(isset($_POST['enter'])){
    if($_POST['name'] != ""){
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    }
    else{
        echo '<span class="error">Please type in a name</span>';
    }
}*/
?>

<!--Start-->
<!DOCTYPE html>

<html lang="en">

<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Lingle - Home</title>
    
    <link rel="stylesheet" href="style.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="chat.js"></script>
    <script type="text/javascript">
    
        // ask user for name with popup prompt    
        var name = prompt("Enter your chat name:", "Guest");
        
        // default name is 'Guest'
    	if (!name || name === ' ') {
    	   name = "Guest";	
    	}
    	
    	// strip tags
    	name = name.replace(/(<([^>]+)>)/ig,"");
    	
    	// display name on page
    	$("#name-area").html("You are: <span>" + name + "</span>");
    	
    	// kick off chat
        var chat =  new Chat();
    	$(function() {
    	
    		 chat.getState(); 
    		 
    		 // watch textarea for key presses
             $("#sendie").keydown(function(event) {  
             
                 var key = event.which;  
           
                 //all keys including return.  
                 if (key >= 33) {
                   
                     var maxLength = $(this).attr("maxlength");  
                     var length = this.value.length;  
                     
                     // don't allow new content if length is maxed out
                     if (length >= maxLength) {  
                         event.preventDefault();  
                     }  
                  }  
    		 																																																});
    		 // watch textarea for release of key press
    		 $('#sendie').keyup(function(e) {	
    		 					 
    			  if (e.keyCode == 13) { 
    			  
                    var text = $(this).val();
    				var maxLength = $(this).attr("maxlength");  
                    var length = text.length; 
                     
                    // send 
                    if (length <= maxLength + 1) { 
                     
    			        chat.send(text, name);
                        /*ADDHERE*/
    			        $(this).val("");
    			        
                    } else {
                    
    					$(this).val(text.substring(0, maxLength));
    					
    				}	
    				
    				
    			  }
             });
            
    	});
    </script>
</head>
<body onload="setInterval('chat.update()', 1000)">

<?php
/*if(!isset($_SESSION['name'])){
        loginForm();
    }
    else{
        if(isset($_GET['logout'])){ 
            //Simple exit message
            $fp = fopen("log.txt", 'a');
            fwrite($fp, "<div class='msgln'><i>User ". $_SESSION['name'] ." has left the chat session.</i><br></div>");
            fclose($fp);
     
            session_destroy();
            header("Location: chat.php"); //Redirect the user
        }*/
?>

    <table class="backcolor">
        <tr class="menuback">
		    <td>
                <img src="Banner.png" height="150em" width="100%">
            </td>
        </tr>
        <tr class="menuback">
            <td>
	            <ul>
                    <li><a href="index.html" ><b >Home</b></a></li>
                    <li><a href="chat.php" ><b>Chat</b></a></li>
                    <li><a href="contact.html" ><b>Contact Us</b></a></li>
                    <li><a href="how.html" ><b>How It Works</b></a></li>
                </ul>
            </td>
        </tr>
    </table>
	<table class="details" align="center">
        <!--Announcements-->
		<tr class="detail">
			<td width="25%"  ><b>Announcement:</b> </td><td width="25%" colspan="2" ><marquee> Cat loves Dogs!</marquee></td>
		</tr>
        <!--BBC news-->
		<tr>
		    <td width="25%" rowspan="3" class="detail2">
                <!--Feedwind code -->
                <script type="text/javascript">
                    document.write('\x3Cscript type="text/javascript" src="' + ('https:' == document.location.protocol ? 'https://' : 'http://') + 'feed.mikle.com/js/rssmikle.js">\x3C/script>');
                </script>
                <script type="text/javascript">
                    (function() {
                        var params = {
                            rssmikle_url: "http://feeds.bbci.co.uk/news/world/rss.xml|http://www.cbn.com/cbnnews/world/feed/|http://feeds.reuters.com/Reuters/worldNews",
                            rssmikle_frame_width: "300",
                            rssmikle_frame_height: "400",
                            frame_height_by_article: "0",
                            rssmikle_target: "_blank",
                            rssmikle_font: "Arial, Helvetica, sans-serif",
                            rssmikle_font_size: "12",
                            rssmikle_border: "off",
                            responsive: "off",
                            rssmikle_css_url: "",
                            text_align: "left",
                            text_align2: "left",
                            corner: "off",
                            scrollbar: "on",
                            autoscroll: "on",
                            scrolldirection: "up",
                            scrollstep: "3",
                            mcspeed: "20",
                            sort: "Off",
                            rssmikle_title: "on",
                            rssmikle_title_sentence: "RSS Feed",
                            rssmikle_title_link: "http://none",
                            rssmikle_title_bgcolor: "#0430de",
                            rssmikle_title_color: "#FFFFFF",
                            rssmikle_title_bgimage: "",
                            rssmikle_item_bgcolor: "#FFFFFF",
                            rssmikle_item_bgimage: "",
                            rssmikle_item_title_length: "55",
                            rssmikle_item_title_color: "#0430de",
                            rssmikle_item_border_bottom: "on",
                            rssmikle_item_description: "on",
                            item_link: "off",
                            rssmikle_item_description_length: "100",
                            rssmikle_item_description_color: "#666666",
                            rssmikle_item_date: "gl1",
                            rssmikle_timezone: "Etc/GMT",
                            datetime_format: "%b %e, %Y %l:%M %p",
                            item_description_style: "text+tn",
                            item_thumbnail: "full",
                            item_thumbnail_selection: "auto",
                            article_num: "15",
                            rssmikle_item_podcast: "off",
                            keyword_inc: "",
                            keyword_exc: ""
                        };
                        feedwind_show_widget_iframe(params);
                    })();
                </script>
                <!--End feedwind code-->
            </td>
            <!--Outputbox-->
            <td>
                <p class="welcome">Welcome, <b><?php/* echo $_SESSION['name']; */?></b></p>
                

    <div id="page-wrap">
    

        
        <p id="name-area"></p>
        
        <div id="chat-wrap"><div id="chat-area"></div></div>
        
        <form id="send-message-area">
            <p>Your message: </p>
            <textarea id="sendie" maxlength = '100' ></textarea>
        </form>
    
    </div>

			    
            </td>
			<td width="25%" class="detail3">
                <button type="submit" value="Send" class="button">Leave Chat</button><br>
                <button type="submit" value="Send" class="button">Report</button></td>
		</tr>
		<tr>
		    <td width="25%" rowspan="2"  class="detail2">advertisement</td>
		</tr>
    </table><hr class="attributes">
    <!--Bottom of page-->
    <table class="backpara">
        <tr>
            <td class="para1"><h2>ONLINE CHATTERS</h2> </td>
            <td class="para1"><h2>WEBSITE NEWS</h2></td>
            <td class="para2"><h2>POPULAR CHAT TOPICS</h2></td>
        </tr>
        <tr>
			<td class="para1"> <h1>53</h1></td>
            <td class="para1"><h3></h3></td>
			<td>
                <h3>
                    <a href="index.html" class="linkh3">Entertainment</a><br>
                    <a href="index.html" class="linkh3">Cats vs Dogs</a><br>
                    <a href="index.html" class="linkh3">How great is Lingle? ;)</a>
                </h3>
            </td>
	    </tr>
    </table>
    <table class="width">
	    <tr>
            <td class="footer"><p class="textdisp">Copyright@Lingle.inc. 2016</p></td>
        </tr>
    </table>

    <div id="sourceText">
    <?php echo $_POST['message']; ?>
    </div>
    <div id="translation"></div>
    <div id="messages"></div>
        <script>
      function translateText(response) {
        document.getElementById("translation").innerHTML += "<br>" + response.data.translations[0].translatedText;
      }
    </script>
    <script>
        var newScript = document.createElement('script');
        newScript.type = 'text/javascript';
        var text = escape(document.getElementById("text").innerHTML);
        // WARNING: be aware that YOUR-API-KEY inside html is viewable by all your users.
        // Restrict your key to designated domains or use a proxy to hide your key
        // to avoid misusage by other party.
        var source = 'https://www.googleapis.com/language/translate/v2?key=AIzaSyC59610ZIcjelmT6lu6tlkfMGfVree0iJw&source=en&target=de&callback=translateText&q=' + text;
        newScript.src = source;

        // When we add this script to the head, the request is sent off.
        document.getElementsByTagName('head')[0].appendChild(newScript);
        sendMessage();

        function sendMessage() {
            var $entered_text = $("#message").val()
            $("#messages").append($entered_text + "<br>");
            $("#message").val("");
        }
    </script>

</body>
<?php
/*}*/
?>
</html>