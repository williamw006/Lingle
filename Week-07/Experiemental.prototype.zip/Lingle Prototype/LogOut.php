<?php
    session_start();
    session_destroy();

?>
<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Logged Out</title>
    </head>
    <body>
        <h1>You have been logged out.</h1>
        <a href="Chat.php"><h1>Log In</h1></a>
        <a href="Index.php"><h1>Exit Chat</h1></a>
    </body>
</html>
