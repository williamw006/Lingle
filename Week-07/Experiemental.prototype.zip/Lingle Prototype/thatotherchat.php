<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <form>
            <input type="text"id="message" autofocus="true">
            </input>
            <input type="button" value="Send" onclick="sendMessage();"></input>
        </form>
        <div id="messages">
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#messages").keypress(function (e) {
                    e.preventDefault();
                    var key = e.which;
                    if (key == 13)  // the enter key code
                    {
                        sendMessage();
                    }
                });
            })
            function sendMessage() {
                var $entered_text = $("#message").val()
                $("#messages").append($entered_text + "<br>");
                $("#message").val("");
            }

            
        </script>
    </body>
</html>
