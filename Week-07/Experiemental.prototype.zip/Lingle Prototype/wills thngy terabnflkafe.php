
<html>
  <head>
    <title>Translate API Example</title>
  </head>
  <body>
      
      <input type="text"id="message" autofocus="true" >
            </input>
            <input type="button" value="Send" onclick="sendMessage();"></input>
    <div id="sourceText">Hello</div>
    <div id="translation"></div>
    <script>
        

      
    </script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script>

        function translateText(response) {
            document.getElementById("translation").innerHTML += "<br>" + response.data.translations[0].translatedText;
        }

        function doIt() {
            document.getElementsByTagName('head')[0].appendChild(newScript);
        }

        function sendMessage() {
            var $entered_text = $("#message").val();
            $("#sourceText").empty();
            $("#sourceText").append($entered_text + "<br>");
            $("#message").val("");
            translateText($entered_text);
            doIt();
        }

        var newScript = document.createElement('script');
        newScript.type = 'text/javascript';
        var sourceText = escape(document.getElementById("sourceText").innerHTML);
        // WARNING: be aware that YOUR-API-KEY inside html is viewable by all your users. Find a way to hide it?
        var source = 'https://www.googleapis.com/language/translate/v2?key=AIzaSyC59610ZIcjelmT6lu6tlkfMGfVree0iJw&source=en&target=de&callback=translateText&q=' + sourceText;
        newScript.src = source;

        // When we add this script to the head, the request is sent off.
        document.getElementsByTagName('head')[0].appendChild(newScript);





    </script>
  </body>
</html>