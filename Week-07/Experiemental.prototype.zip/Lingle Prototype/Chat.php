<?php
session_start();
 
function loginForm(){
    echo'
    <div id="loginform">
    <form action="Chat.php" method="post">
        <p>Please enter your name to continue:</p>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" />
        <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
    </div>
    ';
}
 
if(isset($_POST['enter'])){
    if($_POST['name'] != ""){
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    }
    else{
        echo '<span class="error">Please type in a name</span>';
    }
}
?>
<HTML>
    <HEAD>
        <link rel="stylesheet" href="ChatStyle.css">
    </HEAD>
<BODY>
    <?php
    if(!isset($_SESSION['name'])){
        loginForm();
    }
    else{
    
    if(isset($_GET['logout'])){ 
     
        //Simple exit message
        $fp = fopen("log.txt", 'a');
        fwrite($fp, "<div class='msgln'><i>User ". $_SESSION['name'] ." has left the chat session.</i><br></div>");
        fclose($fp);
     
        session_destroy();
        header("Location: Chat.php"); //Redirect the user
    }
    ?>
    <div id="wrapper">
        <div id="menu">
            <p class="welcome">Welcome, <b><?php echo $_SESSION['name']; ?></b></p>

            
        
            <p class="logout"><a id="Logout" href="LogOut.php">Log Out</a></p>

            <div style="clear:both"></div>
        </div>    
        <div id="chatbox">
    <?php
    if(file_exists("log.txt") && filesize("log.txt") > 0){
        $handle = fopen("log.txt", "r");
        $contents = fread($handle, filesize("log.txt"));
        fclose($handle);
     
        echo $contents;
    }
    ?></div>
     
        <form name="message" action="Chat.php">
            <input name="usermsg" type="text" id="usermsg" size="63" />
            <input name="submitmsg" type="submit"  id="submitmsg" value="Send" />
        </form>
    </div>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
    <script type="text/javascript" src="scripts.js">
    // jQuery Document
    $(document).ready(function(){
    });
    </script>
    <?php
    }
    ?>
    </body>
</html>

