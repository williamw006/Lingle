<?php
    session_start();
    ?>

    <script language="text/javascript">
    window.alert("it got this far");
    </script>
<?php
    if(isset($_SESSION['name'])) {
        $text = $_POST['text'];
        $text = stripslashes(htmlspecialchars($text));
        $fp = fopen("log.txt", 'a');
        //fwrite($fp, "<div class='msgln'>(".date("g:i A").")<b>".$_SESSION['name']."</b>:".stripslashes(htmlspecialchars($text))."<br></div>");
        fwrite($fp, $text);
        fclose($fp);
    }

    
    //if(isset($_SESSION['name'])) {
    //    $text = $_POST['text'];

    //    $fp = fopen("log.txt", 'w');
    //    //fwrite($fp, "<div class='msgln'>(".date("g:i A").")<b>".$_SESSION['name']."</b>:".stripslashes(htmlspecialchars($text))."<br></div>");
    //    fwrite($fp, "hello");
    //    fclose($fp);
    

?>



